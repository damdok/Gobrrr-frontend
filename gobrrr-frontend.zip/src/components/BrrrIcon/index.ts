export { default } from './BrrrIcon'
