export { default } from './ChangedBrrrIcon'
