export { default } from './SmallValue'
